import sqlite3

class SQLighter:

    def __init__(self, database):
        """Подключаемся к БД и сохраняем курсор соединения"""
        self.connection = sqlite3.connect(database)
        self.cursor = self.connection.cursor()
        self.cursor.execute("""CREATE TABLE IF NOT EXISTS user_tg (
                            id        INTEGER       PRIMARY KEY AUTOINCREMENT,
                            user_id   INTEGER       NOT NULL,
                            user_name VARCHAR (255),
                            status    BOOLEAN       NOT NULL
                                                    DEFAULT (TRUE),
                            admin     BOOLEAN       NOT NULL
                                                    DEFAULT (FALSE),
                            [group]   VARCHAR (255) 
                        );""")
        self.connection.commit()

    def get_users(self, status = True):
        """Получаем всех активных подписчиков бота"""
        with self.connection:
            return self.cursor.execute("SELECT * FROM `user_tg` WHERE `status` = ?", (status,)).fetchall()

    def user_exists(self, user_id):
        """Проверяем, есть ли уже юзер в базе"""
        with self.connection:
            result = self.cursor.execute('SELECT * FROM `user_tg` WHERE `user_id` = ?', (user_id,)).fetchall()
            return bool(len(result))

    def add_users(self, user_id, user_name ,status = True):
        """Добавляем нового подписчика"""
        with self.connection:
            return self.cursor.execute("INSERT INTO `user_tg` (`user_id`, `user_name`, `status`) VALUES(?,?,?)", (user_id,user_name,status))

    def check_status(self, user_id, status):
        with self.connection:
            result = self.cursor.execute('SELECT * FROM `user_tg` WHERE `user_id` = ? AND `status` = ?',(user_id,status)).fetchall()
            return bool(len(result))

    def update_user(self, user_id, user_name, status):
        """Обновляем статус подписки пользователя"""
        with self.connection:
            return self.cursor.execute("UPDATE `user_tg` SET `status` = ? WHERE `user_id` = ? AND `user_name` = ?", (status, user_id, user_name))

    def check_group(self, group_user, user_id):
        with self.connection:
            result = self.cursor.execute("SELECT * FROM `user_tg` WHERE `group` = ? AND `user_id` = ?",(group_user, user_id)).fetchall()
            return bool(len(result))

    def update_group(self, group_user, user_id):
        with self.connection:
            return self.cursor.execute("UPDATE `user_tg` SET `group` = ? WHERE `user_id` = ?",(group_user, user_id))

    def add_admin(self, admin_status, user_id):
        with self.connection:
            return self.cursor.execute("UPDATE `user_tg` SET `admin` = ? WHERE `user_id` = ?",(admin_status, user_id))

    def admin_exist(self, admin_status, user_id):
        with self.connection:
            result = self.cursor.execute('SELECT * FROM `user_tg` WHERE `admin` = ? AND `user_id` = ?', (admin_status,user_id)).fetchall()
            return bool(len(result))

    def return_all_user(self):
        return self.cursor.execute('SELECT * FROM `user_tg`')



    def close(self):
        """Закрываем соединение с БД"""
        self.connection.close()