from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.dispatcher import FSMContext
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from config import TOKEN
from aiogram import Bot, Dispatcher, executor, types
from aiogram.dispatcher.filters import Text
from sqldb import SQLighter
import logging
import keybord as kb
from emoji import emojize


logging.basicConfig(level=logging.INFO)

bot = Bot(token=TOKEN)
dp = Dispatcher(bot, storage=MemoryStorage())

db = SQLighter('db.db')

class AdminStatesEdit(StatesGroup):
    edit_confirm = State()
    group = State()
    group_inf = State()
    group_vet = State()
    megaphone = State()

#команда стар, запуск бота и запись группы пользователя
@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    await message.answer(emojize('Привет! :waving_hand:\n'
                                 'Из какой ты группы:red_question_mark: '),
                         reply_markup=kb.keyboar_creater('start_menu'))

#Вывод всех доступных команд
@dp.message_handler(commands=['help'])
async def start(message: types.Message):
    await message.answer(emojize('start - начало работы\n'
                                 'subscribe - подписаться на рассылку\n'
                                 'unsubscribe - отписаться от рассылки\n'
                                 'group - выбрать группу, сменить группу\n'
                                 'table - расписание вашей группы\n'
                                 'help - вывод всех доступных команд\n'))
    await menu(message)

#команда пописки на рассылку сообщений
@dp.message_handler(commands=['subscribe'])
@dp.message_handler(Text(emojize('Подписаться на рассылку:check_mark:')))
async def subscribe(message: types.Message):
    if(db.check_status(message.from_user.id, True)):
        await message.answer("Вы уже были подписанны на рассылку.")
    else:
        if (not db.user_exists(message.from_user.id)):
            # если юзера нет в базе, добавляем его
            if(message.from_user.username == None):
                db.add_users(message.from_user.id, message.from_user.first_name)
            else:
                db.add_users(message.from_user.id, message.from_user.username)
            await message.answer("Вы успешно подписались на рассылку!")
        else:
            # если он уже есть, то просто обновляем ему статус подписки
            if (message.from_user.username == None):
                db.update_user(message.from_user.id, message.from_user.first_name, True)
            else:
                db.update_user(message.from_user.id, message.from_user.username, True)
            await message.answer("Вы успешно подписались на рассылку!")


# Команда отписки на рассылку
@dp.message_handler(commands=['unsubscribe'])
@dp.message_handler(Text(emojize('Отписаться от рассылки:cross_mark:')))
async def unsubscribe(message: types.Message):
    if(db.check_status(message.from_user.id, False)):
        await message.answer("Вы не были подписанны.")
    else:
        if (not db.user_exists(message.from_user.id)):
            # если юзера нет в базе, добавляем его
            if (message.from_user.username == None):
                db.add_users(message.from_user.id, message.from_user.first_name, False)
            else:
                db.add_users(message.from_user.id, message.from_user.username, False)
            await message.answer("Вы не были подписанны.")
        else:
            # если он уже есть, то просто обновляем ему статус подписки
            if (message.from_user.username == None):
                db.update_user(message.from_user.id, message.from_user.first_name, False)
            else:
                db.update_user(message.from_user.id, message.from_user.username, False)
            await message.answer("Вы успешно отписаны от рассылки.")

@dp.message_handler(Text(emojize("Информатик:robot:")))
async def information_group(message: types.Message):
    resp_text = "Вы записаны в группу Информатиков"
    await message.answer(emojize(resp_text + ":robot:"))
    if (not db.user_exists(message.from_user.id)):
        # если юзера нет в базе, добавляем его
        if (message.from_user.username == None):
            db.add_users(message.from_user.id, message.from_user.first_name)
            db.update_group("Информатик", message.from_user.id)
        else:
            db.add_users(message.from_user.id, message.from_user.username)
            db.update_group("Информатик", message.from_user.id)
        await message.answer("Вы успешно подписались на рассылку")
    else:
        # если он уже есть, то просто обновляем ему статус подписки
        if (message.from_user.username == None):
            db.update_user(message.from_user.id, message.from_user.first_name, True)
            db.update_group("Информатик", message.from_user.id)
        else:
            db.update_user(message.from_user.id, message.from_user.username, True)
            db.update_group("Информатик", message.from_user.id)

    await menu(message)


@dp.message_handler(Text(emojize("Ветеринар:dog_face:")))
async def information_group(message: types.Message):
    resp_text = "Вы записаны в группу Ветеринаров"
    await message.answer(emojize(resp_text + ":dog_face:"))
    if (not db.user_exists(message.from_user.id)):
        # если юзера нет в базе, добавляем его
        if (message.from_user.username == None):
            db.add_users(message.from_user.id, message.from_user.first_name)
            db.update_group("Ветеринар", message.from_user.id)
        else:
            db.add_users(message.from_user.id, message.from_user.username)
            db.update_group("Ветеринар", message.from_user.id)
        await message.answer("Вы успешно подписались на рассылку")
    else:
        # если он уже есть, то просто обновляем ему статус подписки
        if (message.from_user.username == None):
            db.update_user(message.from_user.id, message.from_user.first_name, True)
            db.update_group("Ветеринар", message.from_user.id)
        else:
            db.update_user(message.from_user.id, message.from_user.username, True)
            db.update_group("Ветеринар", message.from_user.id)
    await menu(message)

@dp.message_handler(commands=['group'])
@dp.message_handler(Text(emojize("Сменить группу:counterclockwise_arrows_button:")))
async def update_group(message: types.Message):
    await message.answer(emojize('Выберите группу'), reply_markup=kb.keyboar_creater('start_menu'))

@dp.message_handler(commands=['menu'])
@dp.message_handler(Text(emojize('В стандартное меню:bookmark_tabs:')))
async def menu(message: types.Message):
    if(db.admin_exist(True, message.from_user.id)):
        await message.answer(emojize('Выберите один из пунктов:\n'
                                     '1) Расписание:bookmark_tabs:\n'
                                     '2) Сменить группу:counterclockwise_arrows_button:\n'
                                     '3) Подписаться на рассылку:check_mark:\n'
                                     '4) Отписаться от рассылки:cross_mark:\n'
                                     '5) Админ меню:bald:'),
                             reply_markup=kb.keyboar_creater('menu_button').add(emojize('Админ меню:bald:')))
    else:
        await message.answer(emojize('Выберите один из пунктов:\n'
                                     '1) Расписание:bookmark_tabs:\n'
                                     '2) Сменить группу:counterclockwise_arrows_button:\n'
                                     '3) Подписаться на рассылку:check_mark:\n'
                                     '4) Отписаться от рассылки:cross_mark:'),
                             reply_markup=kb.keyboar_creater('menu_button'))


#Админ меню
@dp.message_handler(commands=['admin_menu'])
@dp.message_handler(Text(emojize('Админ меню:bald:')))
async def admin_menu(message: types.Message):
    if(not db.admin_exist(True, message.from_user.id)):
        return
    await message.answer(emojize('Выберите один из пунктов:\n'
                                 '1) Смотреть/Изменить Расписание:memo:\n'
                                 '2) Сделать объявление:megaphone:\n'
                                 '3) Показать всех пользователей:person:\n'
                                 '4) В стандартное меню:bookmark_tabs:\n'),
                         reply_markup=kb.keyboar_creater('admin_menu'))

async def table_exist(message: types.Message):
    if(db.check_group('Информатик', message.from_user.id)):
        try:
            table = open('img/table_inf.jpg', 'rb')
            await bot.send_photo(message.chat.id, table)
        except FileNotFoundError:
            await message.answer("В данный момент расписание не загружено")
    else:
        try:
            table = open('img/table_vet.jpg', 'rb')
            await bot.send_photo(message.chat.id, table)
        except FileNotFoundError:
            await message.answer("В данный момент расписание не загружено")


@dp.message_handler(commands=['table'])
@dp.message_handler(Text(emojize("Расписание:bookmark_tabs:")))
async def give_table(message: types.Message):
    await table_exist(message)

# @dp.message_handler(content_types=['photo'])
# async def handle_photo(message: types.Message):
#     async def informatik_table():
#         if(db.admin_exist(True, message.from_user.id)):
#             file_id = message.photo[len(message.photo) -1].file_id
#
#             file = await bot.get_file(file_id)
#             file_path = file.file_path
#             await bot.download_file(file_path, f'img/table.jpg')
#             await message.answer("Расписание добавлено")
#             users = db.get_users()
#             for us in users:
#                 await bot.send_photo(us[1],open("img/table_inf.jpg", 'rb'), 'Добавленно новое расписание информатиков!')
#         else:
#             await message.answer("Ваше сообщение не представляет никакой ценности")

    # async def veterinar_table():
    #     if(db.admin_exist(True, message.from_user.id)):
    #         file_id = message.photo[len(message.photo) -1].file_id
    #
    #         file = await bot.get_file(file_id)
    #         file_path = file.file_path
    #         await bot.download_file(file_path, f'img/table.jpg')
    #         await message.answer("Расписание добавлено")
    #         users = db.get_users()
    #         for us in users:
    #             await bot.send_photo(us[1],open("img/table_vet.jpg", 'rb'), 'Добавленно новое расписание ветеринаров!')
    #     else:
    #         await message.answer("Ваше сообщение не представляет никакой ценности")


#
# @dp.message_handler(Text("09.02.07.informatik"))
# async def get_admin(message: types.Message):
#     if (not db.user_exists(message.from_user.id)):
#         # если юзера нет в базе, добавляем его
#         if(message.from_user.username == None):
#             db.add_users(message.from_user.id, message.from_user.first_name)
#         else:
#             db.add_users(message.from_user.id, message.from_user.username)
#         await message.answer("Вы были добавленны в базу данных как администратор")
#
#     db.add_admin(True, message.from_user.id)
#     await message.answer("Вы админ")

#Админ меню функционал

@dp.message_handler(Text(emojize('Смотреть/Изменить Расписание:memo:')), state='*')
async def edit_table(message: types.Message):

    if(not db.admin_exist(True, message.from_user.id)):
        return await message.answer("В доступе отказано.")

    # проверка наличия расписания информатиков
    try:
        with open('img/table_inf.jpg', 'rb') as table_inf:
            await bot.send_photo(message.chat.id, table_inf, "Расписание Информатиков")
    except FileNotFoundError:
        await message.answer("Расписание информатиков отсутствует")

    # проверка наличия расписания ветеринаров
    try:
        with open('img/table_vet.jpg', 'rb') as table_vet:
            await bot.send_photo(message.chat.id, table_vet, "Расписание ветеринаров")
    except FileNotFoundError:
        await message.answer("Расписание ветеринаров отсутствует")

    await message.answer("Внести изменение?", reply_markup=kb.keyboar_creater('yes_no'))
    await AdminStatesEdit.edit_confirm.set()

#Если нужно изменить расписание
@dp.message_handler(Text(emojize("Да:check_mark_button:")), state=AdminStatesEdit.edit_confirm)
async def confirm_edit(message: types.Message):
    await message.answer("Расписание какой группы вы хотите изменить?", reply_markup=kb.keyboar_creater('edit_group_table'))
    await AdminStatesEdit.group.set()


@dp.message_handler(Text(emojize("Информатики:robot:")), state=AdminStatesEdit.group)
async def edit_inf_table(message: types.Message):
    await message.answer("Загрузите фотографию расписания.")
    await AdminStatesEdit.group_inf.set()

@dp.message_handler(content_types=["photo"], state=AdminStatesEdit.group_inf)
async def get_photo(message: types.Message, state: FSMContext):
    if (db.admin_exist(True, message.from_user.id)):
        file_id = message.photo[len(message.photo) - 1].file_id

        file = await bot.get_file(file_id)
        file_path = file.file_path
        await bot.download_file(file_path, f'img/table_inf.jpg')
        await message.answer("Расписание добавлено")
        users = db.get_users()
        for us in users:
            await bot.send_photo(us[1], open("img/table_inf.jpg", 'rb'), 'Добавленно новое расписание информатиков!')
        await state.finish()
        await admin_menu(message)


@dp.message_handler(Text(emojize("Ветеринары:dog_face:")), state=AdminStatesEdit.group)
async def edit_inf_table(message: types.Message):
    await message.answer("Загрузите фотографию расписания.")
    await AdminStatesEdit.group_vet.set()

@dp.message_handler(content_types=["photo"], state=AdminStatesEdit.group_vet)
async def get_photo(message: types.Message, state: FSMContext):
    if (db.admin_exist(True, message.from_user.id)):
        file_id = message.photo[len(message.photo) - 1].file_id

        file = await bot.get_file(file_id)
        file_path = file.file_path
        await bot.download_file(file_path, f'img/table_vet.jpg')
        await message.answer("Расписание добавлено")
        users = db.get_users()
        for us in users:
            await bot.send_photo(us[1], open("img/table_vet.jpg", 'rb'), 'Добавленно новое расписание ветеринар!')
        await state.finish()
        await admin_menu(message)


@dp.message_handler(Text(emojize('Нет:cross_mark:')), state='*')
async def cancel_edit(message: types.Message, state: FSMContext):
    if(not db.admin_exist(True, message.from_user.id)):
        return

    await message.answer("Действие отменено")
    await admin_menu(message)
    await state.finish()

#Показать всех пользователей
@dp.message_handler(Text(emojize('Показать всех пользователей:person:')))
async def show_all_user(message: types.Message):
    if(not db.admin_exist(True, message.from_user.id)):
        return
    users = db.get_users()
    for us in users:
        await message.answer(f'id в БД: {us[0]}\nuser_id: {us[1]}\nuser_name: {us[2]}')

@dp.message_handler(Text(emojize("Сделать объявление:megaphone:")), state='*')
async def megaphone(message: types.Message):

    if(not db.admin_exist(True, message.from_user.id)):
        return

    await bot.send_message(message.chat.id, "Введите сообщение.")
    await AdminStatesEdit.megaphone.set()

@dp.message_handler(content_types=['text'], state=AdminStatesEdit.megaphone)
async def handle_text(message: types.Message, state: FSMContext):
    users = db.get_users()
    for us in users:
        await bot.send_message(us[1], emojize(f'Объявление:megaphone:: {message.text}'))
        await state.finish()


if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)