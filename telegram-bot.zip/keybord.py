from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from emoji import emojize

def keyboar_creater(pattern):
    if pattern == 'start_menu':
        return ReplyKeyboardMarkup(
            keyboard=[
                [
                    KeyboardButton(text=(emojize("Информатик:robot:"))),
                    KeyboardButton(text=(emojize("Ветеринар:dog_face:")))
                ],
            ],
            resize_keyboard=True,
            one_time_keyboard=True
        )

    if pattern == 'menu_button':
        return  ReplyKeyboardMarkup(
            keyboard=[
                [
                    KeyboardButton(text=(emojize("Расписание:bookmark_tabs:")))
                ],
                [
                    KeyboardButton(text=(emojize("Сменить группу:counterclockwise_arrows_button:")))
                ],
                [
                    KeyboardButton(text=(emojize("Подписаться на рассылку:check_mark:"))),
                    KeyboardButton(text=(emojize("Отписаться от рассылки:cross_mark:")))
                ],
            ],
            resize_keyboard=True,
        )

    if pattern == 'admin_menu':
        return ReplyKeyboardMarkup(
            keyboard=[
                [
                    KeyboardButton(text=(emojize("Смотреть/Изменить Расписание:memo:")))
                    ,
                    KeyboardButton(text=(emojize("Сделать объявление:megaphone:")))
                ],
                [
                    KeyboardButton(text=(emojize(("Показать всех пользователей:person:"))))
                    ,
                    KeyboardButton(text=(emojize(("В стандартное меню:bookmark_tabs:"))))
                ],
            ],
            resize_keyboard=True,
            one_time_keyboard=True,
        )
    if pattern == 'yes_no':
        return ReplyKeyboardMarkup(
            keyboard=[
                [
                    KeyboardButton(text=(emojize("Да:check_mark_button:")))
                ],
                [
                    KeyboardButton(text=(emojize("Нет:cross_mark:")))

                ],
            ],
            resize_keyboard=True
        )

    if pattern == 'edit_group_table':
        return ReplyKeyboardMarkup(
            keyboard=[
                [
                    KeyboardButton(text=(emojize("Информатики:robot:"))),
                ],
                [
                    KeyboardButton(text=(emojize("Ветеринары:dog_face:")))
                ],
            ],
            resize_keyboard=True,
            one_time_keyboard=True
        )